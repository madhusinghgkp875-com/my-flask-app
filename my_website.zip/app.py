from flask import Flask, render_template, request

app = Flask(__name__)

# 🛡️ आपकी हाई-सिक्योरिटी की जो आपने बताई थी
app.config['SECRET_KEY'] = '122#31ankit.5y'

# CHS Class 9th Science - High Yield Conceptual Questions
CHS_QUESTIONS = [
    {
        "id": 1,
        "question": "किस धातु को चाकू से आसानी से काटा जा सकता है? (Which metal can be easily cut with a knife?)",
        "options": ["सोडियम (Sodium)", "लोहा (Iron)", "तांबा (Copper)", "सोना (Gold)"],
        "correct": "सोडियम (Sodium)"
    },
    {
        "id": 2,
        "question": "कोशिका का पावरहाउस किसे कहा जाता है? (Powerhouse of the cell is known as:)",
        "options": ["लाइसोसोम", "माइटोकॉन्ड्रिया", "गॉल्जीकाय", "केंद्रक"],
        "correct": "माइटोकॉन्ड्रिया"
    },
    {
        "id": 3,
        "question": "ध्वनि की गति सबसे अधिक किस माध्यम में होती है? (Speed of sound is maximum in:)",
        "options": ["ठोस (Solid)", "द्रव (Liquid)", "गैस (Gas)", "निर्वात (Vacuum)"],
        "correct": "ठोस (Solid)"
    },
    {
        "id": 4,
        "question": "ग्लोबल वार्मिंग के लिए मुख्य रूप से कौन सी गैस जिम्मेदार है?",
        "options": ["CO2 (कार्बन डाइऑक्साइड)", "O2 (ऑक्सीजन)", "N2 (नाइट्रोजन)", "H2 (हाइड्रोजन)"],
        "correct": "CO2 (कार्बन डाइऑक्साइड)"
    }
]

@app.route('/')
def home():
    return render_template('index.html', questions=CHS_QUESTIONS)

@app.route('/submit', methods=['POST'])
def submit():
    score = 0
    results = []
    for q in CHS_QUESTIONS:
        user_answer = request.form.get(f"q_{q['id']}")
        is_correct = user_answer == q['correct']
        if is_correct:
            score += 1
        results.append({
            "question": q['question'],
            "user_answer": user_answer,
            "correct_answer": q['correct'],
            "is_correct": is_correct
        })
    return render_template('result.html', score=score, total=len(CHS_QUESTIONS), results=results)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
